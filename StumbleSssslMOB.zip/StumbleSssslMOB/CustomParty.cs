using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Il2Cpp;
using Il2CppExitGames.Client.Photon;
using Il2CppQuantum;
using Il2CppStumble;
using Il2CppStumble.Matchmaking;
using Il2CppStumble.SpecialEmoteFilter;
using StumbleBeast.Tools;
using UnityEngine;

namespace StumbleBeast.Modules
{
	// Token: 0x02000030 RID: 48
	public static class CustomParty
	{
		// Token: 0x0600007D RID: 125 RVA: 0x00004394 File Offset: 0x00002594
		public static void AddLevel(LevelManager levelManager, CustomParty.CustomLevelData data, LevelGroupDef groupDef)
		{
			LevelDef levelDef = ScriptableObject.CreateInstance<LevelDef>();
			levelDef.name = data.Name;
			levelDef.friendlyName = data.FriendlyName;
			levelDef.UniqueId = data.UniqueId;
			levelDef.levelArt = data.LevelArt;
			levelDef.sceneName = data.SceneName;
			levelDef.leftPanelDescription = ".GG/sghit";
			levelDef.introObjective = ".GG/sghit";
			Il2CppSystem.Collections.Generic.List<LevelGroupDef> list = new Il2CppSystem.Collections.Generic.List<LevelGroupDef>();
			list.Add(groupDef);
			levelDef.Groups = list;
			levelManager._levels.Add(levelDef);
			MapCollectionEntry item = new MapCollectionEntry
			{
				MapGuid = MapCollection.Instance.GetMapGuid(data.FriendlyName),
				MapSceneName = data.SceneName
			};
			bool flag = CustomParty.Maps == null;
			if (flag)
			{
				CustomParty.Maps = MapCollection.Instance._maps.ToList<MapCollectionEntry>();
			}
			CustomParty.Maps.Add(item);
			bool flag2 = !levelManager._cachedGroupLevels.ContainsKey(groupDef);
			if (flag2)
			{
				levelManager._cachedGroupLevels[groupDef] = new Il2CppSystem.Collections.Generic.List<LevelDef>();
			}
			levelManager._cachedGroupLevels[groupDef].Add(levelDef);
			CustomParty.CustomLevels[data.Name] = data;
			CustomParty.CustomSprites[data.Name] = data.SpriteIcon;
		}

		// Token: 0x0600007E RID: 126 RVA: 0x000044E0 File Offset: 0x000026E0
		public static void Initialize()
		{
			LevelManager levelManager = StumbleManager.Get<Initializer>()._levelManager;
			bool flag = levelManager == null;
			if (!flag)
			{
				LevelGroupDef levelGroupDef = ScriptableObject.CreateInstance<LevelGroupDef>();
				levelGroupDef.name = "CustomCategory0";
				levelGroupDef.FriendlyName = "Respawn";
				levelGroupDef.Image = ResourcesManager.GetSprite("beastBGCustom.png");
				levelGroupDef.Maptype = (MapType)1;
				foreach (CustomParty.CustomLevelData data in new List<CustomParty.CustomLevelData>
				{
					new CustomParty.CustomLevelData("Beast Dash", "Beast Dash", "level19_respawnblock", "respawndash", "Respawn Dash", "ReDashBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("Beast Laser", "Beast Laser", "level15_respawnlaser", "respawnlaser", "Respawn Laser", "LaserBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("Beast Legendary", "Beast Legendary", "eventlevel13_block_respawnlegendary", "respawnlegendary", "Respawn Legendary", "LegendBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("Beast Laser Dash", "Beast Laser Dash", "eventlevel1_respawndash", "respawnlaserdash", "Respawn Laser Dash", "LaserDashBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("Beast Endless", "Beast Endless", "eventlevel8_block_respawnendless", "respawnendeless", "Respawn Endless", "EndlessBG.png", (LevelType)1),
					new CustomParty.CustomLevelData("Beast Other Side", "Beast Other Side", "L_042_RespawnChicken", "respawnchicken", "Respawn Other Side", "ChickenBG.png", (LevelType)0)
				})
				{
					CustomParty.AddLevel(levelManager, data, levelGroupDef);
				}
				LevelGroupDef levelGroupDef2 = ScriptableObject.CreateInstance<LevelGroupDef>();
				levelGroupDef2.name = "CustomCategory1";
				levelGroupDef2.FriendlyName = "Endless";
				levelGroupDef2.CanBeUsedWithOnlyOnePlayer = true;
				levelGroupDef2.Image = ResourcesManager.GetSprite("infBGCustom.png");
				levelGroupDef2.Maptype = (MapType)1;
				foreach (CustomParty.CustomLevelData data2 in new List<CustomParty.CustomLevelData>
				{
					new CustomParty.CustomLevelData("endlesslegendary", "Block Dash Legendary Endless", "eventlevel13_block_infinitelegendary", "infinitelegendary", "Infinite Legendary", "LegendBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("endlesslaser", "Laser Tracer Endless", "level15_infinitelaser", "infinitelaser", "Infinite Laser", "LaserBG.png", (LevelType)0),
					new CustomParty.CustomLevelData("endlesslaserdash", "Laser Dash Endless", "eventlevel1_infinitedash", "infinitelaserdash", "Infinite Laser Dash", "LaserDashBG.png", (LevelType)0)
				})
				{
					CustomParty.AddLevel(levelManager, data2, levelGroupDef2);
				}
			}
		}

		// Token: 0x04000036 RID: 54
		public static string CurrentMap = "";

		// Token: 0x04000037 RID: 55
		public static bool DisplayDetails = false;

		// Token: 0x04000038 RID: 56
		public static bool IsEndless;

		// Token: 0x04000039 RID: 57
		public static LevelType LevelType;

		// Token: 0x0400003A RID: 58
		public static bool spawnBlocks;

		// Token: 0x0400003B RID: 59
		public static List<MapCollectionEntry> Maps;

		// Token: 0x0400003C RID: 60
		public static Dictionary<string, CustomParty.CustomLevelData> CustomLevels = new Dictionary<string, CustomParty.CustomLevelData>();

		// Token: 0x0400003D RID: 61
		public static Dictionary<string, string> CustomSprites = new Dictionary<string, string>();

		// Token: 0x02000074 RID: 116
		[HarmonyPatch(typeof(SpecialEmotesFilterService), "IsFeatureEnabled")]
		public static class Patch
		{
			// Token: 0x06000111 RID: 273 RVA: 0x0000863C File Offset: 0x0000683C
			[HarmonyPrefix]
			public static bool Prefix(ref bool __result)
			{
				__result = true;
				return false;
			}
		}

		// Token: 0x02000075 RID: 117
		public class CustomLevelData
		{
			// Token: 0x06000112 RID: 274 RVA: 0x00008652 File Offset: 0x00006852
			public CustomLevelData(string name, string friendly, string uniqueId, string levelArt, string sceneName, string sprite, LevelType type)
			{
				this.Name = name;
				this.FriendlyName = friendly;
				this.UniqueId = uniqueId;
				this.LevelArt = levelArt;
				this.SceneName = sceneName;
				this.SpriteIcon = sprite;
				this.Type = type;
			}

			// Token: 0x0400008D RID: 141
			public string Name;

			// Token: 0x0400008E RID: 142
			public string FriendlyName;

			// Token: 0x0400008F RID: 143
			public string UniqueId;

			// Token: 0x04000090 RID: 144
			public string LevelArt;

			// Token: 0x04000091 RID: 145
			public string SceneName;

			// Token: 0x04000092 RID: 146
			public string SpriteIcon;

			// Token: 0x04000093 RID: 147
			public LevelType Type;
		}

		// Token: 0x02000076 RID: 118
		[HarmonyPatch(typeof(MultiplayerRoomManager), "GetMapName")]
		public static class Patch1
		{
			private static void SetLevelType(Hashtable hashtable, string value)
			{
				hashtable["LevelType"] = value;
			}

			public static bool Prefix(MultiplayerRoomManager __instance, ref string __result)
			{
				MultiplayerRoomManager roomManager = StumbleManager.GetRoomManager();
				if (roomManager == null) return true;
				Hashtable hashtable = roomManager.CloneCustomRoomProperties();
				if (hashtable == null || hashtable["ROUND1_MAP"] == null) return true;
				string a = hashtable["ROUND1_MAP"].ToString();
				bool result;
				if (a == "Respawn Dash")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "level19_block";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "Respawn Laser")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "level15_laser";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "Respawn Legendary")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "eventlevel13_block_legendary";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "Respawn Laser Dash")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "eventlevel1_dash";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "eventlevel8_block_endless")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)1;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "eventlevel8_block_endless";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "Respawn Other Side")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "L_042_Chicken";
					CustomParty.DisplayDetails = true;
					result = false;
				}
				else if (a == "Infinite Laser Dash")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 1.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)1;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "eventlevel1_dash";
					CustomParty.IsEndless = true;
					result = false;
				}
				else if (a == "Infinite Laser")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 1.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)1;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "level15_laser";
					CustomParty.IsEndless = true;
					result = false;
				}
				else if (a == "Infinite Legendary")
				{
					if (QuantumRunner.Default && QuantumManager.GetCurrentMap() != null)
					{
						SetLevelType(hashtable, QuantumManager.GetCurrentMap().type.ToString());
						MultiplayerRoomManager.PhotonClient.CurrentRoom.SetCustomProperties(hashtable, null, null);
						hashtable["LevelType"] = 0.ToString();
						QuantumManager.GetCurrentMap().type = (LevelType)0;
						StumbleManager.Get<UIController>()._initUI = false;
					}
					__result = "eventlevel13_block_legendary";
					CustomParty.IsEndless = true;
					result = false;
				}
				else
				{
					CustomParty.IsEndless = false;
					CustomParty.DisplayDetails = false;
					result = true;
				}
				return result;
			}
		}
	}
}
