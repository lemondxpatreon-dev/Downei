#ifndef CRYPTO_UTILS_H
#define CRYPTO_UTILS_H

#include <vector>
#include <string>
#include <random>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cstring>
#include "../Includes/picosha2.h"

struct CryptoUtils {
    static const char* Salt;
    static const char* LoginSalt;

    static char* Base64Encode(const char* data) {
        if (!data) return nullptr;
        const char* base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::string ret;
        int i = 0, j = 0;
        unsigned char charArray3[3], charArray4[4];
        size_t inLen = strlen(data);
        const char* bytesToEncode = data;

        while (inLen--) {
            charArray3[i++] = *(bytesToEncode++);
            if (i == 3) {
                charArray4[0] = (charArray3[0] & 0xfc) >> 2;
                charArray4[1] = ((charArray3[0] & 0x03) << 4) + ((charArray3[1] & 0xf0) >> 4);
                charArray4[2] = ((charArray3[1] & 0x0f) << 2) + ((charArray3[2] & 0xc0) >> 6);
                charArray4[3] = charArray3[2] & 0x3f;
                for(i = 0; i < 4; i++) ret += base64Chars[charArray4[i]];
                i = 0;
            }
        }

        if (i) {
            for(j = i; j < 3; j++) charArray3[j] = '\0';
            charArray4[0] = (charArray3[0] & 0xfc) >> 2;
            charArray4[1] = ((charArray3[0] & 0x03) << 4) + ((charArray3[1] & 0xf0) >> 4);
            charArray4[2] = ((charArray3[1] & 0x0f) << 2) + ((charArray3[2] & 0xc0) >> 6);
            charArray4[3] = charArray3[2] & 0x3f;
            for (j = 0; j < i + 1; j++) ret += base64Chars[charArray4[j]];
            while(i++ < 3) ret += '=';
        }
        
        char* result = new char[ret.size() + 1];
        strcpy(result, ret.c_str());
        return result;
    }

    static char* Base64Decode(const char* data) {
        if (!data) return nullptr;
        const char* base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::vector<int> base64Lookup(256, -1);
        for (int i = 0; i < 64; i++) base64Lookup[base64Chars[i]] = i;

        int inLen = strlen(data);
        int i = 0, j = 0, inIdx = 0;
        unsigned char charArray4[4], charArray3[3];
        std::string ret;

        while (inLen-- && data[inIdx] != '=') {
            charArray4[i++] = data[inIdx]; inIdx++;
            if (i == 4) {
                for (i = 0; i < 4; i++) charArray4[i] = base64Lookup[charArray4[i]];
                charArray3[0] = (charArray4[0] << 2) + ((charArray4[1] & 0x30) >> 4);
                charArray3[1] = ((charArray4[1] & 0xf) << 4) + ((charArray4[2] & 0x3c) >> 2);
                charArray3[2] = ((charArray4[2] & 0x3) << 6) + charArray4[3];
                for (i = 0; i < 3; i++) ret += charArray3[i];
                i = 0;
            }
        }

        if (i) {
            for (j = i; j < 4; j++) charArray4[j] = 0;
            for (j = 0; j < 4; j++) charArray4[j] = base64Lookup[charArray4[j]];
            charArray3[0] = (charArray4[0] << 2) + ((charArray4[1] & 0x30) >> 4);
            charArray3[1] = ((charArray4[1] & 0xf) << 4) + ((charArray4[2] & 0x3c) >> 2);
            charArray3[2] = ((charArray4[2] & 0x3) << 6) + charArray4[3];
            for (j = 0; j < i - 1; j++) ret += charArray3[j];
        }
        
        char* result = new char[ret.size() + 1];
        strcpy(result, ret.c_str());
        return result;
    }

    static char* HashSHA256(const char* input) {
        if (!input) return nullptr;
        std::string hash_hex_str;
        picosha2::hash256_hex_string(input, input + strlen(input), hash_hex_str);
        char* result = new char[hash_hex_str.size() + 1];
        strcpy(result, hash_hex_str.c_str());
        return result;
    }

    static char* HashSHA1(const char* input) {
        if (!input) return nullptr;
        
        unsigned int h0 = 0x67452301;
        unsigned int h1 = 0xEFCDAB89;
        unsigned int h2 = 0x98BADCFE;
        unsigned int h3 = 0x10325476;
        unsigned int h4 = 0xC3D2E1F0;

        std::string msg = input;
        uint64_t origLen = msg.length();
        uint64_t origBitLen = origLen * 8;

        msg += (char)0x80;
        while ((msg.length() % 64) != 56) msg += (char)0x00;

        for (int i = 0; i < 8; i++) msg += (char)((origBitLen >> ((7 - i) * 8)) & 0xFF);

        for (size_t chunk = 0; chunk < msg.length(); chunk += 64) {
            unsigned int w[80];
            for (int i = 0; i < 16; i++) {
                w[i] = ((unsigned char)msg[chunk + i * 4] << 24) |
                       ((unsigned char)msg[chunk + i * 4 + 1] << 16) |
                       ((unsigned char)msg[chunk + i * 4 + 2] << 8) |
                       ((unsigned char)msg[chunk + i * 4 + 3]);
            }
            for (int i = 16; i < 80; i++) {
                w[i] = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16];
                w[i] = (w[i] << 1) | (w[i] >> 31);
            }

            unsigned int a = h0, b = h1, c = h2, d = h3, e = h4;

            for (int i = 0; i < 80; i++) {
                unsigned int f, k;
                if (i < 20) {
                    f = (b & c) | ((~b) & d);
                    k = 0x5A827999;
                } else if (i < 40) {
                    f = b ^ c ^ d;
                    k = 0x6ED9EBA1;
                } else if (i < 60) {
                    f = (b & c) | (b & d) | (c & d);
                    k = 0x8F1BBCDC;
                } else {
                    f = b ^ c ^ d;
                    k = 0xCA62C1D6;
                }

                unsigned int temp = ((a << 5) | (a >> 27)) + f + e + k + w[i];
                e = d;
                d = c;
                c = (b << 30) | (b >> 2);
                b = a;
                a = temp;
            }

            h0 += a; h1 += b; h2 += c; h3 += d; h4 += e;
        }

        std::stringstream ss;
        ss << std::hex << std::setfill('0');
        ss << std::setw(8) << h0 << std::setw(8) << h1 << std::setw(8) << h2 << std::setw(8) << h3 << std::setw(8) << h4;
        std::string resultStr = ss.str();
        
        char* result = new char[resultStr.size() + 1];
        strcpy(result, resultStr.c_str());
        return result;
    }

    static char* EncryptWithIV(const char* data, const char* ivStr, const char* key) {
        if (!data || !ivStr || !key) return nullptr;
        
        char* ivBytes = Base64Decode(ivStr);
        if (!ivBytes || strlen(ivBytes) != 16) {
            delete[] ivBytes;
            return nullptr;
        }
        
        size_t dataLen = strlen(data);
        size_t padLen = 16 - (dataLen % 16);
        char* paddedData = new char[dataLen + padLen + 1];
        strcpy(paddedData, data);
        for (size_t i = 0; i < padLen; i++) paddedData[dataLen + i] = static_cast<char>(padLen);
        paddedData[dataLen + padLen] = '\0';
        
        unsigned char* encryptedBytes = new unsigned char[dataLen + padLen];
        size_t keyLen = strlen(key);
        size_t ivLen = 16;
        
        for (size_t i = 0; i < dataLen + padLen; i++) {
            unsigned char dataByte = paddedData[i];
            unsigned char keyByte = key[i % keyLen];
            unsigned char ivByte = ivBytes[i % ivLen];
            encryptedBytes[i] = dataByte ^ keyByte ^ ivByte;
        }
        
        char* encryptedStr = new char[dataLen + padLen + 1];
        strncpy(encryptedStr, reinterpret_cast<char*>(encryptedBytes), dataLen + padLen);
        encryptedStr[dataLen + padLen] = '\0';
        
        char* result = Base64Encode(encryptedStr);
        
        delete[] ivBytes;
        delete[] paddedData;
        delete[] encryptedBytes;
        delete[] encryptedStr;
        
        return result;
    }

    static char* DecryptWithIV(const char* encryptedData, const char* ivStr, const char* key) {
        if (!encryptedData || !ivStr || !key) return nullptr;
        
        char* encryptedBytes = Base64Decode(encryptedData);
        char* ivBytes = Base64Decode(ivStr);
        
        if (!encryptedBytes || !ivBytes || strlen(ivBytes) != 16) {
            delete[] encryptedBytes;
            delete[] ivBytes;
            return nullptr;
        }
        
        size_t dataLen = strlen(encryptedBytes);
        unsigned char* decryptedBytes = new unsigned char[dataLen];
        size_t keyLen = strlen(key);
        size_t ivLen = 16;
        
        for (size_t i = 0; i < dataLen; i++) {
            unsigned char encryptedByte = encryptedBytes[i];
            unsigned char keyByte = key[i % keyLen];
            unsigned char ivByte = ivBytes[i % ivLen];
            decryptedBytes[i] = encryptedByte ^ keyByte ^ ivByte;
        }
        
        char* result = new char[dataLen + 1];
        strncpy(result, reinterpret_cast<char*>(decryptedBytes), dataLen);
        result[dataLen] = '\0';
        
        size_t padLen = result[dataLen - 1];
        if (padLen > 0 && padLen <= dataLen) {
            result[dataLen - padLen] = '\0';
        }
        
        delete[] encryptedBytes;
        delete[] ivBytes;
        delete[] decryptedBytes;
        
        return result;
    }

    static char* Encrypt(const char* data) {
        if (!data) return nullptr;
        const char* key = Salt;
        size_t dataLen = strlen(data);
        size_t keyLen = strlen(key);
        unsigned char* encryptedBytes = new unsigned char[dataLen];
        for (size_t i = 0; i < dataLen; i++) {
            char dataByte = data[i];
            char keyByte = key[i % keyLen];
            encryptedBytes[i] = dataByte ^ keyByte;
        }
        char* encryptedStr = new char[dataLen + 1];
        strncpy(encryptedStr, reinterpret_cast<char*>(encryptedBytes), dataLen);
        encryptedStr[dataLen] = '\0';
        char* result = Base64Encode(encryptedStr);
        delete[] encryptedBytes;
        delete[] encryptedStr;
        return result;
    }

    static char* Decrypt(const char* data) {
        if (!data) return nullptr;
        const char* key = Salt;
        size_t keyLen = strlen(key);
        char* encryptedBytes = Base64Decode(data);
        if (!encryptedBytes) return nullptr;
        size_t dataLen = strlen(encryptedBytes);
        unsigned char* decryptedBytes = new unsigned char[dataLen];
        for (size_t i = 0; i < dataLen; i++) {
            char encryptedByte = encryptedBytes[i];
            char keyByte = key[i % keyLen];
            decryptedBytes[i] = encryptedByte ^ keyByte;
        }
        char* result = new char[dataLen + 1];
        strncpy(result, reinterpret_cast<char*>(decryptedBytes), dataLen);
        result[dataLen] = '\0';
        delete[] encryptedBytes;
        delete[] decryptedBytes;
        return result;
    }

    static char* GenerateId() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 15);
        std::stringstream ss;
        ss << std::hex;
        for (int i = 0; i < 32; i++) {
            if (i == 8 || i == 12 || i == 16 || i == 20) ss << "-";
            ss << dis(gen);
        }
        std::string resultStr = ss.str();
        char* result = new char[resultStr.size() + 1];
        strcpy(result, resultStr.c_str());
        return result;
    }

    static char* SessionToken() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 255);
        char randomBytes[16];
        for (int i = 0; i < 16; i++) randomBytes[i] = (char)dis(gen);
        char* token = Base64Encode(randomBytes);
        for (int i = 0; token[i]; i++) {
            if (token[i] == '+') token[i] = '-';
            else if (token[i] == '/') token[i] = '_';
        }
        char* eqPos = strchr(token, '=');
        if (eqPos) *eqPos = '\0';
        return token;
    }

    static char* GenCaracters(int amount) {
        const char* chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, strlen(chars) - 1);
        char* result = new char[amount + 1];
        for (int i = 0; i < amount; i++) result[i] = chars[dis(gen)];
        result[amount] = '\0';
        return result;
    }

    static char* CreateLoginHash(const char* deviceId, const char* id, const char* stumbleId, const char* version) {
        std::string buffer = std::string(LoginSalt) + deviceId + id + stumbleId + version;
        return HashSHA256(buffer.c_str());
    }

    static char* CreateRegularHash(const char* username, const char* id, const char* deviceId, const char* token, const char* stumbleId, const char* url, const char* body = "NULL") {
        std::string buffer = std::string(Salt) + username + id + deviceId + token + stumbleId + url + body;
        return HashSHA256(buffer.c_str());
    }

    static char* GenAndroidId() {
        return GenerateId();
    }

    static char* GenWebGLId() {
        char* androidId = GenAndroidId();
        char* result = new char[strlen("webgl_") + strlen(androidId) + 1];
        strcpy(result, "webgl_");
        strcat(result, androidId);
        delete[] androidId;
        return result;
    }

    static char* GenIosId() {
        char* id = GenerateId();
        for (int i = 0; id[i]; i++) id[i] = toupper(id[i]);
        return id;
    }
};

const char* CryptoUtils::Salt = "Qz8gC5xK1nVZpb3AeTf6wDqMb2JLhY9R";
const char* CryptoUtils::LoginSalt = "Qz8gC5xK1nVZpb3AeTf6wDqMb2JLhY9R";

#endif