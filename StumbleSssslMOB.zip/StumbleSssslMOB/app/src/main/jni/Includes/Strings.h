#pragma once
#ifndef STRINGS_H
#define STRINGS_H

#include "Utils.h"

struct String
{
    void* klass;
    void* monitor;
    int length;
    char chars[1];
    
    int getLength()
    {
        return length;
    }
    
    char* getChars()
    {
        return chars;
    }
    
    static String* Create(const char* str);
};

extern String* (*buildString)(void* _this, char* value, int startIndex, int length);

#endif
