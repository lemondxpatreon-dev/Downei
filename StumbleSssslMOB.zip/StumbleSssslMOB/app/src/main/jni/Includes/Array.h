#pragma once
#ifndef ARRAY_H
#define ARRAY_H

template <typename T>
struct monoArray
{
    void* klass;
    void* monitor;
    void* bounds;
    int   max_length;
    void* vector[1];
    
    int getLength()
    {
        return max_length;
    }

    T getPointer()
    {
        return (T)vector;
    }
    
    #define targetLibName OBFUSCATE("libil2cpp.so")
    static monoArray<void**>* FindObject(void* Type)
    {
        static const auto green_fn = (monoArray<void**>*(*)(void*)) (getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), 0x37EB32C)); 
        return green_fn(Type);
    }
};

#endif
