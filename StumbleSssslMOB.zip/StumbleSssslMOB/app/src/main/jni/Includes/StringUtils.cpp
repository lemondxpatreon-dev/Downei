#include "Strings.h"
#include <cstring>

String* (*buildString)(void* _this, char* value, int startIndex, int length) = nullptr;

String* String::Create(const char* str) {
    if (buildString && str) {
        int len = strlen(str);
        return buildString(NULL, (char*)str, 0, len);
    }
    return nullptr;
}
